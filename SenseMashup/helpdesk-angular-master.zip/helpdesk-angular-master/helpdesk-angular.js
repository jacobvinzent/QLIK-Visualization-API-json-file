/*global require*/
/*
 * Bootstrap and angular-based mashup
 * @owner Erik Wetterberg (ewg)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );

var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};

require.config( {
	baseUrl: (config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "" ) + config.prefix + "resources"
} );

require( ["js/qlik"], function ( qlik ) {
	//qlik app
	var app;
	//data for case listing
	

	function getQlikApp () {
		//return qlik.openApp( "4bf04442-aa89-43ff-870a-917c86c92990", config )
		return qlik.openApp( "Helpdesk Management.qvf", config )
	}


	// Defining Module
	//
	var helpdeskApp = angular.module( "helpdeskApp", ['ngRoute'] );
	//
	// Defining Routes
	//
	helpdeskApp.config( function ( $routeProvider ) {
		$routeProvider.when( '/cases', {
			templateUrl: 'cases.html',
			controller: 'CaseCtrl'
		} ).
			otherwise( {
				controller: 'MainCtrl',
				templateUrl: './main.html'
			} );
	} );
	//controllers
	helpdeskApp.controller( "MainCtrl", ['$scope', function ( $scope ) {
		if ( !app ) {
			app = getQlikApp();
		}
		//get objects -- inserted here --
	



		var xmlhttp = new XMLHttpRequest();
		var url = "vizapi.json";
		 $scope.objs =[];
		$scope.myArr;

		xmlhttp.onreadystatechange = function() {
		    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
		         myArr = JSON.parse(xmlhttp.responseText);
				  
				  myFunction(myArr);
				  qlik.resize();
		    }
		};
		xmlhttp.open("GET", url, true);
		xmlhttp.send();

		function myFunction(arr) {
			 for(i = 0; i < arr.length; i++) {
		    	
		    	
		    	var obj = {};
		    	if(arr[i].qProperty.visualization!='filterpane')
		    	{
		    	obj["Id"] = arr[i].qProperty.qInfo.qId;
		    	obj["VizType"] = arr[i].qProperty.visualization;
		    	obj["Def"] = arr[i].qProperty;
		    	    	$scope.objs.push(obj);
		    	}
		    	else
		    		{
		    	
		    		for (var h = 0; h <arr[i].qChildren.length; h++) 
		    			{
		    				obj["Id"]=       arr[i].qChildren[h].qProperty.qInfo.qId;
		    				obj["VizType"] = arr[i].qChildren[h].qProperty.visualization;
		    				obj["Def"] =     arr[i].qChildren[h].qProperty;			
		    		    	$scope.objs.push(obj);
		    		    	obj = {};
		    			}
		    	
		    		}
				
		    	}
		    	
		    }


	}] );

	
helpdeskApp.directive("qplaceholder", function(){
	    
	    return {
	    
	        replace: true,
	        restrict: 'A', 
	        scope: false, //default
	        link: function(scope, element, attrs){ 
	            
	            

	        if (undefined != scope.objs)
	            for (var i = 0; i < scope.objs.length; i++) {
	            	if(scope.objs[i].Id==attrs.qplaceholder)
	            	{
	            
	            				app.visualization.create(scope.objs[i]["VizType"], null, scope.objs[i]["Def"])
	   							.then(function(barchart) {
	      						barchart.show(attrs.id)
	    					});
	            	}
	            };
	            
	        }
	    }
	});


	// bootstrap my angular application, including the "qlik-angular" module
	// must be done before the Qlik Sense API is used
	// you must also set qva-bootstrap="false" in your html file
	angular.bootstrap( document, ["helpdeskApp", "qlik-angular"] );
	qlik.setOnError( function ( error ) {
		//TODO:bootstrap removes html elements on dismiss..should hide instead
		$( "#errmsg" ).html( error.message ).parent().show();
	} );


	//

} );

